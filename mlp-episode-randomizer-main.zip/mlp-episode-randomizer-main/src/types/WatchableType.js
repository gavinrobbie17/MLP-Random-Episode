export type WatchableType =
  'EPISODE' |
  'DOUBLE_EPISODE' |
  'SPECIAL' |
  'EQUESTRIA_GIRLS'

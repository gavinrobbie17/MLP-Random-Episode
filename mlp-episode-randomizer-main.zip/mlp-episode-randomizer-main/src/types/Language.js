// Keep in sync with Language
export const Languages = [
  'English',
  'German',
]

// Keep in sync with Languages
export type Language =
  'English' |
  'German'

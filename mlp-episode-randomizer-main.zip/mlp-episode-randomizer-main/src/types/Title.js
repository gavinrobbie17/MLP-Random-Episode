export interface Title {
  english: string,
  german?: string,
}
